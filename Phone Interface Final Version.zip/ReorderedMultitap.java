 //Authors: Gianna Ritzko & Andrew Buxton
public class ReorderedMultitap extends Multitap {
/**
 * The constructor for this class allows for keys in Multitap to be overwritten for a Reordered entry method
 */
	public ReorderedMultitap(){
		super.keys[2]="acb";
		super.keys[3]="edf";
		super.keys[4]="ihg";
		super.keys[5]="lkj";
		super.keys[6]="onm";
		super.keys[7]="srpq";
		super.keys[8]="tuv";
		super.keys[9]="wyxz";
	}//constructor
}//Class
